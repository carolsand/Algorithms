import { Row } from "./types";

export function writeOutput(table: Row[]) {
    table.forEach((row) => {
        // Write row to excel or wherever you want the data.
        console.log(
            row.project,
            row.product,
            row.plannedFinishDate,
            row.grilleType,
            row.interiorExteriorColor
        );
    });
    // console.log(table);
}
