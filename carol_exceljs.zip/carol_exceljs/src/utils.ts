/**
 * Swaps array positions of two items in place.
 *
 * It takes into account that the upper index may be larger than the array
 * length.
 *
 * @param arr An array of any type
 * @param index1 The lower index to swap
 * @param index2 The higher index to swap
 * @returns void because it mutates the array
 */
export function swapArrayLocations<T>(
    arr: T[],
    index1: number,
    index2: number
): void {
    if (index2 >= arr.length || index1 >= arr.length) {
        // Can't swap with an index that doesn't exist.
        return;
    }
    const temp = arr[index1];
    arr[index1] = arr[index2];
    arr[index2] = temp;
}
