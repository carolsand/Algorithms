import _ from "lodash";
import { rawData } from "./data";
import { Row } from "./types";
import { loadData } from "./loader";
import {
    sorter,
    groupByColor,
    sortGroupByProductType,
    preventFourGrillesInARow,
} from "./sorters";
import { writeOutput } from "./output";

function main() {
    const table = loadData(rawData);
    const firstSort = table.sort(sorter); // everything sorted up to this point
    const groupedByColor = groupByColor(firstSort);
    const orderedByProductType = groupedByColor.map(sortGroupByProductType);
    const fixedGrilleGroups: Row[][] = orderedByProductType.map((group) =>
        preventFourGrillesInARow(group)
    );

    fixedGrilleGroups.forEach((group) => {
        writeOutput(group);
        console.log("----");
    });

    const result = _.flatten(fixedGrilleGroups);

    // TODO: the `result` is the final 2D array.
}

main();
