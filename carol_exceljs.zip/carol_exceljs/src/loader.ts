import { Row, ProductType, Color } from "./types";

function createRow(rowData: string[]): Row {
    // TODO: write error checking for the current row. For example, if the
    // length or types aren't correct or whatever, skip the row by returning
    // null or whatever.
    return {
        project: rowData[0],
        product: rowData[1] as ProductType,
        customItem: rowData[2],
        updateGroup: Number(rowData[3]),
        updateSequence: Number(rowData[4]),
        plannedFinishDate: new Date(rowData[5]),
        prpQuantity: Number(rowData[6]),
        // index 7 is duplicate
        interiorExteriorColor: rowData[8] as Color,
        grilleType: rowData[9],
        // originalType: rowData[9],
    };
}

export function loadData(data: string): Row[] {
    const rows = data.split("\n").filter((line) => line.trim());
    // I split the columns on whitespace here, and they can be reassembled later.
    const grid = rows.map((row) =>
        createRow(row.split(/\s+/).map((cell) => cell.trim()))
    );
    return grid;
}
