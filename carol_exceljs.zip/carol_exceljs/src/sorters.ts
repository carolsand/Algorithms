import _ from "lodash";
import { Row } from "./types";
import { orderSequence } from "./data";
import { swapArrayLocations } from "./utils";

export function sorter(a: Row, b: Row) {
    if (a.interiorExteriorColor === b.interiorExteriorColor) {
        return a.plannedFinishDate < b.plannedFinishDate ? -1 : 1;
    } else {
        return a.interiorExteriorColor > b.interiorExteriorColor ? -1 : 1;
    }
}

export function groupByColor(table: Row[]): Row[][] {
    const result: Row[][] = [];
    let currentColor = table[0].interiorExteriorColor;
    let currentGroup: Row[] = [];

    for (let i = 0; i < table.length; i++) {
        if (table[i].interiorExteriorColor === currentColor) {
            currentGroup.push(table[i]);
        } else {
            result.push(currentGroup);
            currentGroup = [table[i]];
            currentColor = table[i].interiorExteriorColor;
        }
    }
    return result;
}

/**
 * Order the rows in a group by product type.
 *
 * @param group A group of table rows that is pre-sorted according to color and
 * date.
 */
export function sortGroupByProductType(group: Row[]): Row[] {
    const result: Row[] = [];
    let sequenceCounter = 0;

    while (group.length > 0) {
        const currentProductType = orderSequence[sequenceCounter];
        const groupCopy = group.slice(0);

        for (let i = 0; i < groupCopy.length; i++) {
            if (group[i].product === currentProductType) {
                result.push(group[i]);
                group.splice(i, 1);
                break;
            }
        }
        sequenceCounter = (sequenceCounter + 1) % orderSequence.length;
        continue;
    }
    return result;
}

/**
 * Prevent more than 4 grilles in a row.
 *
 * This function can be modified to add other logic rules about how many grille
 * types can be in a row.
 *
 * @param group An array of rows that are ordered by everything except grilleType duplicates.
 * @returns The final ordered array of rows.
 */
export function preventFourGrillesInARow(group: Row[]): Row[] {
    const counted = _.countBy(group, (item) => item.grilleType);
    // console.log("counted", counted);

    let grilleTypesInARow = 0;
    let currentGrilleType = group[0].grilleType;

    // loop over rows
    for (let i = 0; i < group.length; i++) {
        // decrement the grilleType counter
        counted[group[i].grilleType]--;
        // if there are 4 of those in a row, see if there are any other of that
        if (group[i].grilleType === currentGrilleType) {
            grilleTypesInARow++;
        }

        // grilleType coming up in the future. If not, then doesn't matter.
        if (grilleTypesInARow >= 4 && counted[group[i].grilleType] > 0) {
            swapArrayLocations(group, i, i + 1);
        }
    }

    return group;
}
