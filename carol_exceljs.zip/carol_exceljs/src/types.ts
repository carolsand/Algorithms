export type ProductType = "CS" | "AN" | "CT" | "CD" | "FW";

export type Color =
    | "WHWH"
    | "BKWH"
    | "STST"
    | "WHOK"
    | "WHPN"
    | "CBPN"
    | "BKBK";

export type Row = {
    project: string;
    product: ProductType;
    customItem: string;
    updateGroup: number;
    updateSequence: number;
    plannedFinishDate: Date;
    prpQuantity: number;
    interiorExteriorColor: Color;
    grilleType: string;
    // originalType: string;
};
