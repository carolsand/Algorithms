## Step 1

Load the data into a 2D array.

```javascript
[
  [
    "A98131", // project
    "CS", // customizedItem (part 1)
    "WHWH14161491", // customizedItem (part 2)
    "25", // newBat...
    "110", // newBin
    "01-17-23", // planFinDt
    "1",
    "CS",
    "WHWH",
    "gbg",
  ],
  [
    "B96775",
    "CT",
    "STST14511343",
    "100",
    "110",
    "01-17-23",
    "1",
    "CT",
    "STST",
    "n",
  ],
  // etc.
];
```

## Step 2

Convert each row into an array of objects.

```javascript
[
  {
    project: "A98131",
    customizedItem1: "CS",
    customizedItem2: "WHWH14161491",
    newBat: "25",
    newBin: "110,
    // etc.
  },
  {
    // etc.
  }
]
```

## Step 3

Sort the array of objects using lodash's `orderBy` function.

```javascript
const sortedTable = _.orderBy(
  table,
  ["customizedItem", "updGrp"],
  ["asc", "asc"]
);
```

## Step 4

Write the sorted table to an Excel file using ExcelJS.
